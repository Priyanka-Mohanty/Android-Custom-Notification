package com.example.priyankam.androidcustomactionnotification;

import android.Manifest;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.content.ContextCompat;
import android.widget.Toast;

/**
 * Created by priyankam on 29-06-2016.
 */
public class HandleCallBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        //Close the notification after click
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.cancel(0);

        //Checking the permission
        try {
            int result = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE);
            if (result == PackageManager.PERMISSION_GRANTED) {

                call(context);
            } else {
                Toast.makeText(context, "Call Failed!", Toast.LENGTH_SHORT).show();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void call(Context context) {
        Toast.makeText(context, "Dialer pad is open.", Toast.LENGTH_SHORT).show();
        //Open the Dialer
        String number = "1234567890";
        Intent i = new Intent(Intent.ACTION_DIAL);
        i.setData(Uri.parse("tel:" + number));
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }


}
