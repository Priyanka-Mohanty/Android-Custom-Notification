package com.example.priyankam.androidcustomactionnotification;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 1;
    static int numMessages = 0;
    Context context;
    String[] perms = {Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();
        //asking permissions for Marshmallow for Phone and sms
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(perms, PERMISSION_REQUEST_CODE);
        }
        Button bcustomnotify = (Button) findViewById(R.id.customnotification);
        Button bcustomnotifyaction = (Button) findViewById(R.id.customnotificationaction);
        bcustomnotify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CustomNotification();

            }
        });
        bcustomnotifyaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CustomNotificationAction();

            }
        });
    }

    private void CustomNotificationAction() {
        // Set Notification Title
        String strTitle = "You have Missed Call !!!";

        //This is the proper solution for Open Some Activity  after clicking the action in notification

        // Open HandleCallBroadcastReceiver Class on "Call" Button Click
        Intent intentCall = new Intent(this, HandleCallBroadcastReceiver.class);
        // Open InfoActivity.java Activity
        PendingIntent pIntentCall = PendingIntent.getBroadcast(this, 0, intentCall, 0);

        // Open HandleCallBroadcastReceiver Class on "Sms" Button Click
        Intent intentSms = new Intent(this, HandleSmsBroadcastReceiver.class);
        // Open HandleSmsBroadcastReceiver.java Activity
        PendingIntent pIntentSms = PendingIntent.getBroadcast(this, 0, intentSms, 0);

        //Create Notification using NotificationCompat.Builder
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                // Set Icon
                .setSmallIcon(R.drawable.ic_launcher)
                // Set Title
                .setContentTitle(strTitle)
                // Add an Action Button below Notification
                .addAction(android.R.drawable.ic_menu_call, "Call", pIntentCall)
                .addAction(android.R.drawable.sym_action_email, "SMS", pIntentSms)
                // Set PendingIntent into Notification
                .setContentIntent(pIntentSms)
                .setContentIntent(pIntentCall)
                // showing action button on notification
                .setPriority(Notification.PRIORITY_MAX)
                .setWhen(0)
                .setColor(0x008141)
                /* Increase notification number every time a new notification arrives */
                .setNumber(++numMessages)

                // Dismiss Notification
                .setAutoCancel(true);

        // Create Notification Manager
        NotificationManager notificationmanager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        // Build Notification with Notification Manager
        notificationmanager.notify(0, builder.build());
    }

    private void CustomNotification() {
        // Set Notification Title
        String strTitle = "You Got New Notification.";
        // Set Notification Text
        String strText = "Hi,How are You?";

        //This is the proper solution for Open Some Activity  after clicking the action in notification

        // Open InfoActivity Class on "Info" Button Click
        Intent intentInfo = new Intent(this, InfoActivity.class);
        // Send data to InfoActivity Class
        intentInfo.putExtra("title", strTitle);
        intentInfo.putExtra("text", strText);
        // Open InfoActivity.java Activity
        PendingIntent pIntentInfo = PendingIntent.getActivity(this, 0, intentInfo, PendingIntent.FLAG_UPDATE_CURRENT);

        //This is the proper solution for dismiss the dialog

        //Create an Intent for the BroadcastReceiver
        Intent intentDismiss = new Intent(context, HandleBroadcastReceiver.class);
        //Create the PendingIntent
        PendingIntent pIntentDismiss = PendingIntent.getBroadcast(context, 0, intentDismiss, 0);

        //Create Notification using NotificationCompat.Builder
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                // Set Icon
                .setSmallIcon(R.drawable.ic_launcher)

                // Set Title
                .setContentTitle(strTitle)
                // Set Text
                .setContentText(strText)
                // Add an Action Button below Notification
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Dismiss", pIntentDismiss)
                .addAction(android.R.drawable.ic_menu_info_details, "Info", pIntentInfo)
                // Set PendingIntent into Notification
                .setContentIntent(pIntentDismiss)
                // showing action button on notification
                .setPriority(Notification.PRIORITY_MAX)
                .setWhen(0)
                .setColor(0x0079c0)
                /* Increase notification number every time a new notification arrives */
                .setNumber(++numMessages)

                // Dismiss Notification
                .setAutoCancel(true);

        // Create Notification Manager
        NotificationManager notificationmanager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        // Build Notification with Notification Manager
        notificationmanager.notify(0, builder.build());
    }


    //checking permissions for Marshmallow for Phone and sms
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:

                boolean audioAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;

                boolean cameraAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                break;
            default:
                break;
        }
    }

}
