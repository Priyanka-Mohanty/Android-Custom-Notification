package com.example.priyankam.androidcustomactionnotification;

import android.Manifest;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.content.ContextCompat;
import android.widget.Toast;

/**
 * Created by priyankam on 29-06-2016.
 */
public class HandleSmsBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        //Close the notification after click
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.cancel(0);

        int result = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS);
        if (result == PackageManager.PERMISSION_GRANTED) {
            sms(context);
        } else {
            Toast.makeText(context, "SMS failed!", Toast.LENGTH_SHORT).show();
        }

    }

    private void sms(Context context) {
        Toast.makeText(context, "Sms is open.", Toast.LENGTH_SHORT).show();
        String number = "123456789";
        Intent n = new Intent(Intent.ACTION_VIEW);
        n.setData(Uri.parse("sms:" + number));
        n.putExtra("sms_body", "Hi,How are You");
        n.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        n.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(n);
    }


}
